package ceka.test.LCWF.code;

import ceka.consensus.gtic.GTIC;
import ceka.converters.FileLoader;
import ceka.core.Dataset;
import ceka.core.Example;
import ceka.core.MultiNoisyLabelSet;
import ceka.test.My1.Alg.MNLDP;
import ceka.test.My1.CekaUtils;
import ceka.test.My3.Alg.AALI;
import ceka.test.My3.Alg.DEWSMV.OptimizedError;
import ceka.test.My3.Alg.LAWMV;
import ceka.test.My3.Alg.MajorityVote;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;

//真实数据集实验测试程序
public class Test_R {
    private static  Dataset m_dataset=null;
    private  static  int  m_nFold=10;


    private static String [] dataname={"music_genre"};



    public void readData(int m_choose) throws Exception {


            String arffXPath = "Ceka-v1.0.1/data/myData1/real-world/" + dataname[m_choose] + "/" + dataname[m_choose] + ".arffx";
            String responsePath = "Ceka-v1.0.1/data/myData1/real-world/" + dataname[m_choose] + "/" + dataname[m_choose] + ".response.txt";
            String goldPath = "Ceka-v1.0.1/data/myData1/real-world/" + dataname[m_choose] + "/" + dataname[m_choose] + ".gold.txt";
            m_dataset = FileLoader.loadFileX(responsePath, goldPath, arffXPath);

    }

    //计算数据集的众包标记质量Crowd label quality(CLQ)
    double datasetQuality(Dataset data){
        double all=0;
        double right=0;
        int labelSize=0;
        for(int i=0;i<data.getExampleSize();i++){
            Example example=data.getExampleByIndex(i);
            MultiNoisyLabelSet muls=example.getMultipleNoisyLabelSet(0);
            labelSize +=muls.getLabelSetSize();
            for(int j=0;j<muls.getLabelSetSize();j++){
                int label=muls.getLabel(j).getValue();
                if(label==example.getTrueLabel().getValue())right++;
                all++;
            }
        }
        System.out.println("label size:"+labelSize);
        return right/all;
    }

    public static void main(String[] args) throws Exception {
        //存放实验结果的文件地址
        String resultPath1 = "Ceka-v1.0.1/src/ceka/test/My3/result/labelQualty_R.txt";
        FileOutputStream fs1 = new FileOutputStream(new File(resultPath1));
        PrintStream result1 = new PrintStream(fs1);
        result1.format("%-20s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s", "Dataset",   "MV","MV+","GTIC","GTIC+","DEWSMV","DEWSMV+","MNLDP","MNLDP+","LAWMV","LAWMV+", "AALI","AALI+");
        result1.println();

        double meanMV=0;
        double meanMV1=0;
        double meanGTIC=0;
        double meanGTIC1=0;
        double meanDEWSMV=0;
        double meanDEWSMV1=0;
        double meanMNLDP=0;
        double meanMNLDP1=0;
        double meanLAWMV=0;
        double meanLAWMV1=0;
        double meanAALI=0;
        double meanAALI1=0;


        for(int i=0;i<dataname.length;i++){

            double accMV=0;
            double accMV1=0;
            double accGTIC=0;
            double accGTIC1=0;
            double accDEWSMV=0;
            double accDEWSMV1=0;
            double accMNLDP=0;
            double accMNLDP1=0;
            double accLAWMV=0;
            double accLAWMV1=0;
            double accAALI=0;
            double accAALI1=0;


            Test_R expriment=new Test_R();
            expriment.readData(i);//读入数据


            for (int nFold = 0; nFold < m_nFold; nFold++) {

                LCWF wf=new LCWF();
                Dataset datasets=CekaUtils.datasetCopy(m_dataset); //拷贝一份数据集
                Dataset s_dataset=wf.workerFilter(datasets,50,80,0.5,0.05);
                System.out.println("before:"+expriment.datasetQuality(m_dataset));
                System.out.println("after:"+expriment.datasetQuality(s_dataset));


                //MV
                Dataset datasetMV= CekaUtils.datasetCopy(m_dataset);
                MajorityVote mv=new MajorityVote();
                mv.doInference(datasetMV);
                accMV += CekaUtils.integrationAccuracy(datasetMV);
                System.out.println("MV :"+ CekaUtils.integrationAccuracy(datasetMV));

                Dataset datasetMV1= CekaUtils.datasetCopy(s_dataset);
                mv.doInference(datasetMV1);
                accMV1 += CekaUtils.integrationAccuracy(datasetMV1);
                System.out.println("MV1 :"+ CekaUtils.integrationAccuracy(datasetMV1));

                //GTIC
                Dataset datasetGTIC=CekaUtils.datasetCopy(m_dataset);
                GTIC gtic = new GTIC("Ceka-v1.0.1/src/ceka/test/My3/result/GTIC/");
                gtic.doInference(datasetGTIC);
                accGTIC +=CekaUtils.integrationAccuracy(datasetGTIC);
                System.out.println("GTIC:"+ CekaUtils.integrationAccuracy(datasetGTIC));
                System.out.println("GTIC finsihed");


                Dataset datasetGTIC1=CekaUtils.datasetCopy(s_dataset);
                GTIC gtic1 = new GTIC("Ceka-v1.0.1/src/ceka/test/My3/result/GTIC/");
                gtic1.doInference(datasetGTIC1);
                accGTIC1 +=CekaUtils.integrationAccuracy(datasetGTIC1);
                System.out.println("GTIC1:"+ CekaUtils.integrationAccuracy(datasetGTIC1));
                System.out.println("GTIC1 finsihed");


                //DEWSMV
                Dataset datasetDeError=CekaUtils.datasetCopy(m_dataset);
                OptimizedError de_error =new OptimizedError();
                de_error.DE_search(datasetDeError);
                accDEWSMV +=CekaUtils.integrationAccuracy(datasetDeError);
                System.out.println("DEWSWMV :"+ CekaUtils.integrationAccuracy(datasetDeError));

                Dataset datasetDeError1=CekaUtils.datasetCopy(s_dataset);
                OptimizedError de_error1 =new OptimizedError();
                de_error1.DE_search(datasetDeError1);
                accDEWSMV1 +=CekaUtils.integrationAccuracy(datasetDeError1);
                System.out.println("DEWSWMV1 :"+ CekaUtils.integrationAccuracy(datasetDeError1));


                //MNLDP
                Dataset datasetMNLDP=CekaUtils.datasetCopy(m_dataset);
                MNLDP mnldp=new MNLDP();
                mnldp.doInference(datasetMNLDP);
                accMNLDP+=CekaUtils.integrationAccuracy(datasetMNLDP);
                System.out.println("MNLDP :"+ CekaUtils.integrationAccuracy(datasetMNLDP));


                Dataset datasetMNLDP1=CekaUtils.datasetCopy(s_dataset);
                MNLDP mnldp1=new MNLDP();
                mnldp1.doInference(datasetMNLDP1);
                accMNLDP1 +=CekaUtils.integrationAccuracy(datasetMNLDP1);
                System.out.println("MNLDP1 :"+ CekaUtils.integrationAccuracy(datasetMNLDP1));

               //LAWMV
                Dataset datasetLAWMV=CekaUtils.datasetCopy(m_dataset);
                LAWMV lawmv = new LAWMV();
                lawmv.doInference(datasetLAWMV, (int)(0.5*datasetLAWMV.numInstances() / datasetLAWMV.numClasses()));
                accLAWMV +=CekaUtils.integrationAccuracy(datasetLAWMV);
                System.out.println("LAWMV :"+ CekaUtils.integrationAccuracy(datasetLAWMV));


                Dataset datasetLAWMV1=CekaUtils.datasetCopy(s_dataset);
                LAWMV lawmv1 = new LAWMV();
                lawmv1.doInference(datasetLAWMV1, (int)(0.5*datasetLAWMV1.numInstances() / datasetLAWMV1.numClasses()));
                accLAWMV1 +=CekaUtils.integrationAccuracy(datasetLAWMV1);
                System.out.println("LAWMV1:"+ CekaUtils.integrationAccuracy(datasetLAWMV1));


                //AALI
                Dataset datasetAALI = CekaUtils.datasetCopy(m_dataset);
                AALI aali = new AALI();
                datasetAALI=aali.doInference(datasetAALI);
                accAALI +=CekaUtils.integrationAccuracy(datasetAALI);
                System.out.println("AALI :"+ CekaUtils.integrationAccuracy(datasetAALI));

                Dataset datasetAALI1 = CekaUtils.datasetCopy(s_dataset);
                 aali = new AALI();
                datasetAALI1=aali.doInference(datasetAALI1);
                accAALI1 +=CekaUtils.integrationAccuracy(datasetAALI1);
                System.out.println("AALI1 :"+ CekaUtils.integrationAccuracy(datasetAALI1));



                System.out.println("################################################");
                System.out.println(dataname[i]+" "+nFold+" fold finshed");
                System.out.println("################################################");
            }


            accMV=accMV/(double)m_nFold;
            accMV1=accMV1/(double)m_nFold;
            accGTIC=accGTIC/(double)m_nFold;
            accGTIC1=accGTIC1/(double)m_nFold;
            accMNLDP=accMNLDP/(double)m_nFold;
            accMNLDP1=accMNLDP1/(double)m_nFold;
            accLAWMV=accLAWMV/(double) m_nFold;
            accLAWMV1=accLAWMV1/(double) m_nFold;
            accAALI=accAALI/(double) m_nFold;
            accAALI1=accAALI1/(double) m_nFold;


            meanMV += accMV;
            meanMV1 += accMV1;
            meanGTIC +=accGTIC;
            meanGTIC1 +=accGTIC1;
            meanMNLDP +=accMNLDP;
            meanMNLDP1 +=accMNLDP1;
            meanLAWMV +=accLAWMV;
            meanLAWMV1 +=accLAWMV1;
            meanAALI +=accAALI;
            meanAALI1 +=accAALI1;



            result1.format("%-20s %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f", dataname[i],
                    accMV, accMV1,accGTIC,accGTIC1,accDEWSMV, accDEWSMV1,accMNLDP,accMNLDP1,accLAWMV,accLAWMV1, accAALI, accAALI1);
            result1.println();
            System.out.println();
        }
        meanMV/=dataname.length;
        meanMV1/=dataname.length;
        meanGTIC /=dataname.length;
        meanGTIC1 /=dataname.length;
        meanDEWSMV /=dataname.length;
        meanDEWSMV1 /=dataname.length;
        meanMNLDP /=dataname.length;
        meanMNLDP1 /=dataname.length;
        meanLAWMV /=dataname.length;
        meanLAWMV1 /=dataname.length;
        meanAALI /=dataname.length;
        meanAALI1 /=dataname.length;



        result1.format("%-20s %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f","Mean",
                meanMV,meanMV1,meanGTIC,meanGTIC1,meanDEWSMV, meanDEWSMV1,meanMNLDP,meanMNLDP1,meanLAWMV,meanLAWMV1, meanAALI, meanAALI1);
        result1.println();
        result1.close();
        System.out.println();



    }
}
