
package ceka.test.LCWF.code;

import ceka.core.*;
import ceka.utils.DatasetManipulator;
import weka.classifiers.Classifier;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.RevisionHandler;
import weka.core.Utils;

import java.io.BufferedReader;
import java.io.FileReader;

public class CekaUtils implements RevisionHandler{

	// ����һ����Χ�ڵ������
	public static double randdouble(double max, double min) {
		return (Math.random() * (max - min) + min);
	}

	//��������
	public static Dataset datasetCopy(Dataset dataset) {

		Dataset newdataset = dataset.generateEmpty();

		// ���
		int numCateSize = dataset.getCategorySize();
		for (int i = 0; i < numCateSize; i++) {
			Category cate = dataset.getCategory(i);
			newdataset.addCategory(cate.copy());
		}

		// ����
		for (int j = 0; j < dataset.getExampleSize(); j++) {
			Example example = dataset.getExampleByIndex(j);
			newdataset.addExample(example);
		}

		// ����
		for (int i = 0; i < dataset.getWorkerSize(); i++) {
			newdataset.addWorker(dataset.getWorkerByIndex(i));
		}

		return newdataset;
	}

	// ���㼯�ɾ���
	public static double integrationAccuracy(Dataset dataset) {

		int numNoisyExample = 0;
		for (int i = 0; i < dataset.getExampleSize(); i++) {
			Example example = dataset.getExampleByIndex(i);
			if (example.getIntegratedLabel().getValue() != example.getTrueLabel().getValue())
				numNoisyExample++;
		}
		return 100 - (100 * numNoisyExample / (double) dataset.getExampleSize());

	}

	// ����������
	public static double noiseRatio(Dataset dataset) {

		int numNoisyExample = 0;
		for (int i = 0; i < dataset.getExampleSize(); i++) {
			Example example = dataset.getExampleByIndex(i);
			if (example.getIntegratedLabel().getValue() != example.getTrueLabel().getValue())
				numNoisyExample++;
		}
		/*return 100 - (100 * numNoisyExample / (double) dataset.getExampleSize());*/
		return (100 * numNoisyExample / (double) dataset.getExampleSize());
	}

	//���ݼ��е���������
	public static double numNoise(Dataset dataset) {

		int numNoisyExample = 0;
		for (int i = 0; i < dataset.getExampleSize(); i++) {
			Example example = dataset.getExampleByIndex(i);
			if (example.getIntegratedLabel().getValue() != example.getTrueLabel().getValue())
				numNoisyExample++;
		}
		return numNoisyExample;
	}

	//��instances��װ��dataset
	public static Dataset instancesToDataset(Instances instances,Dataset dataset1) {
		Dataset dataset = new Dataset(instances,instances.numInstances());
		for(int m = 0;m < dataset1.getCategorySize();m++) {
			Category cate = dataset1.getCategory(m);
			dataset.addCategory(cate.copy());
		}
		for(int i = 0;i < instances.numInstances();i++) {
			Instance instance = instances.instance(i);
			Integer truevalue = (int)instance.classValue();
			Example example = new Example(instance);
			Label truelabel = new Label(null, truevalue.toString(), example.getId(), "creat");
			example.setTrueLabel(truelabel);
			dataset.addExample(example);

		}
		return dataset;
	}

	//��ȡ���ݼ���MV���ɱ�ǩ
	public static int[] getDatasetMVMVIntegratedL(int numExamples, String mvIntegratedLPath) throws Exception {
		// read mvIntegratedL file
		FileReader reader = new FileReader(mvIntegratedLPath);
		BufferedReader readerBuffer = new BufferedReader(reader);
		String line = null;
		int[] mvIntegratedL = new int[numExamples];

		int i = 0;
		while((line = readerBuffer.readLine()) != null) {
			String [] subStrs = line.split("[ \t]");
			mvIntegratedL[i] = Integer.parseInt(subStrs[1]);
			i++;
		}
		readerBuffer.close();
		reader.close();
		return mvIntegratedL;
	}

	// ʮ��ʮ�۽�����֤�����ྫ�Ȳ��ԱȽϵ�����������ʵ��ǩ,���°�
	public static double classificationAccuracy(Dataset dataset, int times, int nFold, Classifier classifier) throws Exception {
		double acc = 0;
		for (int i = 0; i < times; i++) {
			// �з�Ϊ10��
			Dataset[] sumDataset = DatasetManipulator.split(dataset, nFold, true);
			// ѡ��һ����Ϊ���Լ�������9�ݺϲ�Ϊѵ����
			for (int j = 0; j < nFold; j++) {
				int counts = 0;
				Dataset[] trainTestDataset = DatasetManipulator.pickCombine(sumDataset, j);
				classifier.buildClassifier(trainTestDataset[0]);
				for (int k = 0; k < trainTestDataset[1].getExampleSize(); k++) {
					if ((int) classifier.classifyInstance(trainTestDataset[1].instance(k)) == trainTestDataset[1]
							.getExampleByIndex(k).getTrueLabel().getValue()) {
						counts++;
					}
				}
				acc += (double)counts / trainTestDataset[1].numInstances();
			}
		}
		return (acc / times / nFold) * 100;
	}

	public static double[][]getLD(Dataset dataset){

		//            //��ȡÿ�����˵���ÿһ���ϵĴ��׼ȷ��
		//int num_worker=dataset.getExampleByIndex(0).getMultipleNoisyLabelSet(0).getLabelSetSize();
//		int num_worker=80;
//            double[][] workerQuality=new double[num_worker][2];
//            double[][] workerNumber=new double[num_worker][2];
//			for(int i=0;i<dataset.getWorkerSize();i++){
//				for(int j=0;j<2;j++){
//					workerNumber[i][j]=0;
//					workerQuality[i][j]=0;
//				}
//			}
//            for(int j=0;j<dataset.getExampleSize();j++){
//                Example e=dataset.getExampleByIndex(j);
//                MultiNoisyLabelSet multipleNoisyLabelSet = e.getMultipleNoisyLabelSet(0);
//                for(int k=0;k<multipleNoisyLabelSet.getLabelSetSize();k++){
//                    Label label = multipleNoisyLabelSet.getNoisyLabelByWorkerId(""+k);
//                    //��j��ʵ����k�����˵Ĵ��
//
//                    if(label !=null)
//					{
//						int value=label.getValue();
//						workerNumber[k][value]++;
//                    if(value==e.getTrueLabel().getValue())workerQuality[k][value]++;}
//                }
//            }
//            for(int r=0;r<num_worker;r++){
//                for(int c=0;c<2;c++){
//					if(workerNumber[r][c]!=0)
//                    workerQuality[r][c]=workerQuality[r][c]/workerNumber[r][c];
//                }
//            }

		//����ѵ�����е�����ʵ��
		double[][] classvalues = new double[dataset.getExampleSize()][2];

		for (int j = 0; j < dataset.getExampleSize(); j++) {
			Example e = dataset.getExampleByIndex(j);
			MultiNoisyLabelSet multipleNoisyLabelSet = e.getMultipleNoisyLabelSet(0);
			for (int k = 0; k < multipleNoisyLabelSet.getLabelSetSize(); k++) {
				Label label = multipleNoisyLabelSet.getLabel(k);
				//��j��ʵ����k�����˵Ĵ��

//                        System.out.print(value+" ");

					int value = label.getValue();
					classvalues[j][value] +=1;


			}
			Utils.normalize(classvalues[j]);
//            if(classvalues[j][0]-classvalues[j][1]>=0.55)
//            {classvalues[j][0]=1;classvalues[j][1]=0;}
//            else if(classvalues[j][1]-classvalues[j][0]>=0.55){classvalues[j][0]=0;classvalues[j][1]=1;}


		}
		return classvalues;

	}
	//����F1
	public static double[] F1CleanAndRecallNoise(Dataset cleanset, Dataset noiseset) {

		double[] results = new double[3];

		int numCleanExampleClean = 0;
		int numNoiseExampleClean = 0;
		for (int i = 0; i < cleanset.getExampleSize(); i++) {
			Example example = cleanset.getExampleByIndex(i);
			if (example.getIntegratedLabel().getValue() == example.getTrueLabel().getValue())
				numCleanExampleClean++;
			else numNoiseExampleClean++;
		}

		int numNoiseExampleNoise = 0;
		for (int i = 0; i < noiseset.getExampleSize(); i++) {
			Example example = noiseset.getExampleByIndex(i);
			if (example.getIntegratedLabel().getValue() != example.getTrueLabel().getValue())
				numNoiseExampleNoise++;
		}

		results[0] = (double)numNoiseExampleNoise * 100 / (double)noiseset.getExampleSize();
		results[1] = (double)numNoiseExampleNoise * 100 / (double)(numNoiseExampleNoise + numNoiseExampleClean);
		results[2] = (2.0 * (double)numNoiseExampleNoise) / (double)(noiseset.getExampleSize() + cleanset.getExampleSize() + numNoiseExampleNoise - numCleanExampleClean);

		return results;
	}



    @Override
	public String getRevision() {
		// TODO Auto-generated method stub
		return null;
	}

}
